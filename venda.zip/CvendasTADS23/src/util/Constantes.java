/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author clebe
 */
public class Constantes {
    public static final int INSERT_MODE = 0;
    public static final int EDIT_MODE = 1;
}
